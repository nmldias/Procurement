/** @type {import('tailwindcss').Config} */
import { colors, typography, spacing, shadows, borderRadius } from './src/styles/tokens'

export default {
  darkMode: ["class"],
  content: [
    './src/**/*.{js,jsx,ts,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        ...colors,
        border: colors.neutral[200],
        input: colors.neutral[200],
        ring: colors.primary[500],
        background: colors.neutral[50],
        foreground: colors.neutral[900],
        primary: {
          DEFAULT: colors.primary[500],
          foreground: "white",
          ...colors.primary
        },
        secondary: {
          DEFAULT: colors.neutral[500],
          foreground: "white",
          ...colors.neutral
        },
        destructive: {
          DEFAULT: colors.error[500],
          foreground: "white",
          ...colors.error
        },
        muted: {
          DEFAULT: colors.neutral[100],
          foreground: colors.neutral[600],
        },
        accent: {
          DEFAULT: colors.primary[100],
          foreground: colors.primary[900],
        },
        card: {
          DEFAULT: "white",
          foreground: colors.neutral[900],
        },
        success: colors.success,
        warning: colors.warning,
        error: colors.error,
        info: colors.info,
      },
      fontFamily: typography.fontFamily,
      fontSize: typography.fontSize,
      fontWeight: typography.fontWeight,
      lineHeight: typography.lineHeight,
      letterSpacing: typography.letterSpacing,
      spacing,
      boxShadow: shadows,
      borderRadius,
      container: {
        center: true,
        padding: "2rem",
        screens: {
          "2xl": "1400px",
        },
      },
      keyframes: {
        "accordion-down": {
          from: { height: 0 },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: 0 },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
      },
    },
  },
  plugins: [],
}
