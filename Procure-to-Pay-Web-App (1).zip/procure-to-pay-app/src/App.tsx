import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import Dashboard from './pages/Dashboard'
import Requisitions from './pages/Requisitions'
import PurchaseOrders from './pages/PurchaseOrders'
import Invoices from './pages/Invoices'
import Vendors from './pages/Vendors'
import Reports from './pages/Reports'
import MainLayout from './components/layout/MainLayout'
import CreatePurchaseOrder from './pages/CreatePurchaseOrder'
import WorkflowDesignerPage from './pages/WorkflowDesignerPage'
import Settings from './pages/Settings'

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<MainLayout />}>
          <Route index element={<Dashboard />} />
          <Route path="requisitions" element={<Requisitions />} />
          <Route path="purchase-orders" element={<PurchaseOrders />} />
          <Route path="create-purchase-order" element={<CreatePurchaseOrder />} />
          <Route path="invoices" element={<Invoices />} />
          <Route path="vendors" element={<Vendors />} />
          <Route path="reports" element={<Reports />} />
          <Route path="settings" element={<Settings />} />
          <Route path="settings/workflows" element={<WorkflowDesignerPage />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
    </Router>
  )
}

export default App
