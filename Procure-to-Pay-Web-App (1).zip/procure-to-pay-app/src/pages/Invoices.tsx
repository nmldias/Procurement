import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import {
  Table, TableHeader, TableBody, TableHead, TableRow, TableCell
} from '../components/ui/table'
import { Button } from '../components/ui/button'
import { Input } from '../components/ui/input'
import { Card, CardContent } from '../components/ui/card'
import { Search, Filter, CreditCard, MoreHorizontal, Upload, DollarSign } from 'lucide-react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs'

// Mock data for invoices
const mockInvoices = [
  {
    id: 'INV-2023-001',
    poNumber: 'PO-2023-002',
    vendor: 'AV Solutions Inc',
    vendorInvoiceId: 'A12345',
    amount: '$3,750.00',
    status: 'Approved',
    dueDate: '2023-07-15',
    dateCreated: '2023-06-15',
    paymentStatus: 'Scheduled'
  },
  {
    id: 'INV-2023-002',
    poNumber: 'PO-2023-001',
    vendor: 'Microsoft Corp',
    vendorInvoiceId: 'MS-INV-5678',
    amount: '$5,800.00',
    status: 'Pending Approval',
    dueDate: '2023-07-20',
    dateCreated: '2023-06-20',
    paymentStatus: 'Unpaid'
  },
  {
    id: 'INV-2023-003',
    poNumber: 'PO-2023-004',
    vendor: 'Food & Co',
    vendorInvoiceId: 'FC-2023-456',
    amount: '$2,200.00',
    status: 'Exception',
    dueDate: '2023-07-10',
    dateCreated: '2023-06-10',
    paymentStatus: 'On Hold'
  },
  {
    id: 'INV-2023-004',
    poNumber: 'PO-2023-005',
    vendor: 'Dell Technologies',
    vendorInvoiceId: 'DT-892375',
    amount: '$8,500.00',
    status: 'Paid',
    dueDate: '2023-06-30',
    dateCreated: '2023-06-02',
    paymentStatus: 'Paid'
  },
  {
    id: 'INV-2023-005',
    poNumber: 'PO-2023-003',
    vendor: 'Staples Inc',
    vendorInvoiceId: 'SI-45678',
    amount: '$1,250.00',
    status: 'Approved',
    dueDate: '2023-07-15',
    dateCreated: '2023-06-18',
    paymentStatus: 'Scheduled'
  },
];

const StatusBadge = ({ status, type }: { status: string, type: 'approval' | 'payment' }) => {
  let bgColor = '';

  if (type === 'approval') {
    switch (status) {
      case 'Approved':
        bgColor = 'bg-green-100 text-green-800';
        break;
      case 'Pending Approval':
        bgColor = 'bg-yellow-100 text-yellow-800';
        break;
      case 'Exception':
        bgColor = 'bg-red-100 text-red-800';
        break;
      case 'Paid':
        bgColor = 'bg-blue-100 text-blue-800';
        break;
      default:
        bgColor = 'bg-gray-100 text-gray-800';
    }
  } else {
    // Payment status
    switch (status) {
      case 'Paid':
        bgColor = 'bg-green-100 text-green-800';
        break;
      case 'Scheduled':
        bgColor = 'bg-purple-100 text-purple-800';
        break;
      case 'Unpaid':
        bgColor = 'bg-yellow-100 text-yellow-800';
        break;
      case 'On Hold':
        bgColor = 'bg-red-100 text-red-800';
        break;
      default:
        bgColor = 'bg-gray-100 text-gray-800';
    }
  }

  return (
    <span className={`px-2 py-1 rounded-full text-xs font-medium ${bgColor}`}>
      {status}
    </span>
  );
};

const InvoicesTable = ({ invoices }: { invoices: typeof mockInvoices }) => {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Invoice #</TableHead>
          <TableHead>PO Number</TableHead>
          <TableHead>Vendor</TableHead>
          <TableHead>Vendor Invoice #</TableHead>
          <TableHead>Amount</TableHead>
          <TableHead>Status</TableHead>
          <TableHead>Payment Status</TableHead>
          <TableHead>Due Date</TableHead>
          <TableHead className="w-[80px]"></TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {invoices.length === 0 ? (
          <TableRow>
            <TableCell colSpan={9} className="text-center py-8">
              <div className="flex flex-col items-center">
                <CreditCard className="h-8 w-8 text-muted-foreground mb-2" />
                <p className="text-muted-foreground">No invoices found</p>
              </div>
            </TableCell>
          </TableRow>
        ) : (
          invoices.map((invoice) => (
            <TableRow key={invoice.id}>
              <TableCell>
                <Link to={`/invoices/${invoice.id}`} className="text-primary hover:underline">
                  {invoice.id}
                </Link>
              </TableCell>
              <TableCell>
                <Link to={`/purchase-orders/${invoice.poNumber}`} className="text-primary hover:underline">
                  {invoice.poNumber}
                </Link>
              </TableCell>
              <TableCell>{invoice.vendor}</TableCell>
              <TableCell>{invoice.vendorInvoiceId}</TableCell>
              <TableCell>{invoice.amount}</TableCell>
              <TableCell>
                <StatusBadge status={invoice.status} type="approval" />
              </TableCell>
              <TableCell>
                <StatusBadge status={invoice.paymentStatus} type="payment" />
              </TableCell>
              <TableCell>{invoice.dueDate}</TableCell>
              <TableCell>
                <Button variant="ghost" size="icon">
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </TableCell>
            </TableRow>
          ))
        )}
      </TableBody>
    </Table>
  );
};

const Invoices: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState("all");

  // Filter invoices based on search and tab
  const filteredInvoices = mockInvoices.filter(invoice => {
    // First apply search filter
    const matchesSearch =
      invoice.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      invoice.poNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      invoice.vendor.toLowerCase().includes(searchTerm.toLowerCase()) ||
      invoice.vendorInvoiceId.toLowerCase().includes(searchTerm.toLowerCase());

    if (!matchesSearch) return false;

    // Then apply tab filter
    switch (activeTab) {
      case "pending":
        return invoice.status === "Pending Approval";
      case "approved":
        return invoice.status === "Approved";
      case "exceptions":
        return invoice.status === "Exception";
      case "paid":
        return invoice.paymentStatus === "Paid";
      default:
        return true; // "all" tab
    }
  });

  return (
    <div className="space-y-6">
      <div className="flex justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Invoices</h1>
          <p className="text-muted-foreground">
            Track and manage all vendor invoices and payments.
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Upload className="mr-2 h-4 w-4" />
            Upload Invoice
          </Button>
          <Button>
            <DollarSign className="mr-2 h-4 w-4" />
            Process Payments
          </Button>
        </div>
      </div>

      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-between mb-4">
            <div className="relative w-64">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search invoices..."
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Button variant="outline" size="sm">
              <Filter className="mr-2 h-4 w-4" />
              Filter
            </Button>
          </div>

          <Tabs defaultValue="all" className="mb-4" onValueChange={setActiveTab}>
            <TabsList>
              <TabsTrigger value="all">All Invoices</TabsTrigger>
              <TabsTrigger value="pending">Pending</TabsTrigger>
              <TabsTrigger value="approved">Approved</TabsTrigger>
              <TabsTrigger value="exceptions">Exceptions</TabsTrigger>
              <TabsTrigger value="paid">Paid</TabsTrigger>
            </TabsList>
            <TabsContent value="all">
              <InvoicesTable invoices={filteredInvoices} />
            </TabsContent>
            <TabsContent value="pending">
              <InvoicesTable invoices={filteredInvoices} />
            </TabsContent>
            <TabsContent value="approved">
              <InvoicesTable invoices={filteredInvoices} />
            </TabsContent>
            <TabsContent value="exceptions">
              <InvoicesTable invoices={filteredInvoices} />
            </TabsContent>
            <TabsContent value="paid">
              <InvoicesTable invoices={filteredInvoices} />
            </TabsContent>
          </Tabs>

          <div className="flex items-center justify-end mt-4 space-x-2">
            <Button variant="outline" size="sm" disabled>
              Previous
            </Button>
            <Button variant="outline" size="sm">
              Next
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default Invoices
