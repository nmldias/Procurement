import React from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card'
import {
  FileText,
  ShoppingCart,
  Clock,
  Receipt,
  TrendingUp,
  AlertTriangle,
  ArrowUp,
  ArrowDown
} from 'lucide-react'
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell
} from 'recharts'
import { Button } from '../components/ui/button'

// Monthly spend data for the bar chart
const monthlySpendData = [
  { name: 'Jan', IT: 4000, Office: 2400, Marketing: 1200 },
  { name: 'Feb', IT: 3000, Office: 1398, Marketing: 2800 },
  { name: 'Mar', IT: 2000, Office: 3800, Marketing: 1500 },
  { name: 'Apr', IT: 2780, Office: 3908, Marketing: 2000 },
  { name: 'May', IT: 1890, Office: 4800, Marketing: 2181 },
  { name: 'Jun', IT: 2390, Office: 3800, Marketing: 2500 },
];

// Budget vs Actual data for the line chart
const budgetVsActualData = [
  { name: 'Jan', Budget: 10000, Actual: 8500 },
  { name: 'Feb', Budget: 12000, Actual: 11000 },
  { name: 'Mar', Budget: 13000, Actual: 14500 },
  { name: 'Apr', Budget: 15000, Actual: 14200 },
  { name: 'May', Budget: 16000, Actual: 15800 },
  { name: 'Jun', Budget: 14000, Actual: 16200 },
];

// Top spend categories for pie chart
const topSpendCategoriesData = [
  { name: 'IT Equipment', value: 35 },
  { name: 'Office Supplies', value: 20 },
  { name: 'Marketing', value: 15 },
  { name: 'Services', value: 10 },
  { name: 'Other', value: 20 },
];

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#A569BD'];

const StatCard = ({
  title,
  value,
  change,
  changeType = 'positive',
  icon: Icon
}: {
  title: string;
  value: string | number;
  change?: string;
  changeType?: 'positive' | 'negative' | 'neutral';
  icon: React.ElementType;
}) => {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            <div className={`h-10 w-10 rounded-full flex items-center justify-center
              ${changeType === 'positive' ? 'bg-green-100 text-green-600' :
                changeType === 'negative' ? 'bg-red-100 text-red-600' :
                'bg-blue-100 text-blue-600'}`}>
              <Icon className="h-5 w-5" />
            </div>
            <h3 className="text-sm font-medium text-gray-500 ml-3">{title}</h3>
          </div>
          {change && (
            <div className={`text-xs font-medium flex items-center
              ${changeType === 'positive' ? 'text-green-600' :
                changeType === 'negative' ? 'text-red-600' :
                'text-blue-600'}`}>
              {changeType === 'positive' ? <ArrowUp className="h-3 w-3 mr-1" /> :
               changeType === 'negative' ? <ArrowDown className="h-3 w-3 mr-1" /> : null}
              {change}
            </div>
          )}
        </div>
        <div className="flex items-center justify-between">
          <div className="text-3xl font-bold">{value}</div>
          <Button variant="link" size="sm" className="text-blue-600 p-0 h-auto">
            View details
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

// First time user experience welcome message component
const FirstTimeUserMessage = ({ onClose }: { onClose: () => void }) => {
  return (
    <div className="bg-blue-50 border-l-4 border-blue-500 p-4 mb-6 rounded-md">
      <div className="flex">
        <div className="flex-shrink-0">
          <FileText className="h-5 w-5 text-blue-600" aria-hidden="true" />
        </div>
        <div className="ml-3">
          <h3 className="text-sm font-medium text-blue-800">Welcome to your Procurement Dashboard!</h3>
          <div className="mt-2 text-sm text-blue-700">
            <p>This dashboard gives you an overview of your procurement activities. Here you can:</p>
            <ul className="list-disc pl-5 mt-1 space-y-1">
              <li>Monitor key metrics like requisitions and purchase orders</li>
              <li>Track spending across departments</li>
              <li>Review budget vs. actual expenditure</li>
              <li>Get notified about pending approvals and issues</li>
            </ul>
          </div>
          <div className="mt-3">
            <Button
              onClick={onClose}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              Got it
            </Button>
          </div>
        </div>
        <button
          type="button"
          className="ml-auto flex-shrink-0 text-blue-500 hover:text-blue-600"
          onClick={onClose}
          aria-label="Dismiss welcome message"
        >
          <span className="sr-only">Close</span>
          <XIcon className="h-5 w-5" />
        </button>
      </div>
    </div>
  );
};

// XIcon component for close button
const XIcon = (props: React.SVGProps<SVGSVGElement>) => {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
      <line x1="18" y1="6" x2="6" y2="18"></line>
      <line x1="6" y1="6" x2="18" y2="18"></line>
    </svg>
  );
};

const Dashboard = () => {
  // State to track whether to show the first-time user message
  const [showFirstTimeMessage, setShowFirstTimeMessage] = React.useState(true);

  return (
    <div className="container py-6 space-y-6">
      {/* First Time User Experience */}
      {showFirstTimeMessage && (
        <FirstTimeUserMessage onClose={() => setShowFirstTimeMessage(false)} />
      )}

      <div>
        <h1 className="text-2xl font-bold mb-2">Dashboard</h1>
        <p className="text-muted-foreground">Welcome to your procurement dashboard.</p>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Requisitions"
          value="214"
          change="12% vs. last month"
          changeType="positive"
          icon={FileText}
        />
        <StatCard
          title="Purchase Orders"
          value="186"
          change="8% vs. last month"
          changeType="positive"
          icon={ShoppingCart}
        />
        <StatCard
          title="Pending Approvals"
          value="27"
          changeType="neutral"
          icon={Clock}
        />
        <StatCard
          title="Pending Invoices"
          value="42"
          change="5% vs. last month"
          changeType="negative"
          icon={Receipt}
        />
      </div>

      {/* Spending Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="overflow-hidden">
          <CardHeader className="pb-2">
            <CardTitle>Monthly Spend Overview</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={monthlySpendData}
                  margin={{
                    top: 20,
                    right: 30,
                    left: 20,
                    bottom: 5,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="IT" fill="#3b82f6" />
                  <Bar dataKey="Office" fill="#10b981" />
                  <Bar dataKey="Marketing" fill="#f59e0b" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="overflow-hidden">
          <CardHeader className="pb-2">
            <CardTitle>Budget vs. Actual</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={budgetVsActualData}
                  margin={{
                    top: 20,
                    right: 30,
                    left: 20,
                    bottom: 5,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="Budget" stroke="#3b82f6" strokeWidth={2} />
                  <Line type="monotone" dataKey="Actual" stroke="#ef4444" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Additional Insights */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>Top Spend Categories</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={topSpendCategoriesData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {topSpendCategoriesData.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Alerts & Notifications</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start gap-4 p-3 bg-amber-50 rounded-md border border-amber-100">
                <div className="mt-0.5">
                  <AlertTriangle className="h-5 w-5 text-amber-500" />
                </div>
                <div>
                  <h4 className="font-medium text-amber-700">3 POs awaiting your approval</h4>
                  <p className="text-sm text-amber-600 mt-1">Please review and take action on these purchase orders.</p>
                  <Button variant="link" className="mt-1 h-auto p-0 text-amber-700">Review now</Button>
                </div>
              </div>

              <div className="flex items-start gap-4 p-3 bg-blue-50 rounded-md border border-blue-100">
                <div className="mt-0.5">
                  <TrendingUp className="h-5 w-5 text-blue-500" />
                </div>
                <div>
                  <h4 className="font-medium text-blue-700">Q2 Budget Review Upcoming</h4>
                  <p className="text-sm text-blue-600 mt-1">Quarterly budget review meeting scheduled for June 30.</p>
                  <Button variant="link" className="mt-1 h-auto p-0 text-blue-700">View calendar</Button>
                </div>
              </div>

              <div className="flex items-start gap-4 p-3 bg-red-50 rounded-md border border-red-100">
                <div className="mt-0.5">
                  <AlertTriangle className="h-5 w-5 text-red-500" />
                </div>
                <div>
                  <h4 className="font-medium text-red-700">5 Invoices overdue</h4>
                  <p className="text-sm text-red-600 mt-1">There are 5 invoices that require immediate payment.</p>
                  <Button variant="link" className="mt-1 h-auto p-0 text-red-700">View invoices</Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default Dashboard
