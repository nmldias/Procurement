import React from 'react'
import { Link } from 'react-router-dom'
import {
  Table, TableHeader, TableBody, TableHead, TableRow, TableCell
} from '../components/ui/table'
import { Button } from '../components/ui/button'
import { Input } from '../components/ui/input'
import { Card, CardContent } from '../components/ui/card'
import {
  Search,
  Filter,
  MoreHorizontal,
  CheckCircle,
  XCircle,
  Clock,
  Plus,
  FileText
} from 'lucide-react'

// Mock data for requisitions
const mockRequisitions = [
  {
    id: 'REQ-2023-001',
    title: 'Office Supplies',
    requester: 'John Smith',
    department: 'Marketing',
    totalAmount: 1250.00,
    status: 'Pending Approval',
    dateCreated: '2023-06-15',
  },
  {
    id: 'REQ-2023-002',
    title: 'Software Licenses',
    requester: 'Emily Johnson',
    department: 'IT',
    totalAmount: 5800.00,
    status: 'Approved',
    dateCreated: '2023-06-14',
  },
  {
    id: 'REQ-2023-003',
    title: 'Marketing Services',
    requester: 'David Wilson',
    department: 'Marketing',
    totalAmount: 12500.00,
    status: 'Rejected',
    dateCreated: '2023-06-10',
  },
  {
    id: 'REQ-2023-004',
    title: 'Conference Equipment',
    requester: 'Sarah Miller',
    department: 'Events',
    totalAmount: 3750.00,
    status: 'Approved',
    dateCreated: '2023-06-08',
  },
  {
    id: 'REQ-2023-005',
    title: 'Catering Services',
    requester: 'Michael Brown',
    department: 'Human Resources',
    totalAmount: 2200.00,
    status: 'Pending Approval',
    dateCreated: '2023-06-05',
  },
];

interface StatusBadgeProps {
  status: string;
}

const StatusBadge: React.FC<StatusBadgeProps> = ({ status }) => {
  let bgColor = '';
  let textColor = '';
  let icon = null;
  let ariaLabel = '';

  switch (status) {
    case 'Approved':
      bgColor = 'bg-green-50';
      textColor = 'text-green-800';
      icon = <CheckCircle className="h-3.5 w-3.5 text-green-600 mr-1" aria-hidden="true" />;
      ariaLabel = 'Status: Approved';
      break;
    case 'Rejected':
      bgColor = 'bg-red-50';
      textColor = 'text-red-800';
      icon = <XCircle className="h-3.5 w-3.5 text-red-600 mr-1" aria-hidden="true" />;
      ariaLabel = 'Status: Rejected';
      break;
    case 'Pending Approval':
      bgColor = 'bg-yellow-50';
      textColor = 'text-yellow-800';
      icon = <Clock className="h-3.5 w-3.5 text-yellow-600 mr-1" aria-hidden="true" />;
      ariaLabel = 'Status: Pending Approval';
      break;
    default:
      bgColor = 'bg-gray-100';
      textColor = 'text-gray-800';
      ariaLabel = `Status: ${status}`;
  }

  return (
    <span
      className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium ${bgColor} ${textColor}`}
      role="status"
      aria-label={ariaLabel}
    >
      {icon}
      {status}
    </span>
  );
};

const Requisitions: React.FC = () => {
  return (
    <div className="container py-6 space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-2">
        <div>
          <h1 className="text-2xl font-semibold text-neutral-900 tracking-tight mb-1">Requisitions</h1>
          <p className="text-sm text-neutral-500">Manage and track all purchase requisitions.</p>
        </div>
        <Button
          className="bg-blue-600 hover:bg-blue-700 text-white shadow-sm transition-colors h-10 px-4"
          aria-label="Create new requisition"
        >
          <Plus className="mr-2 h-4 w-4" />
          Create Requisition
        </Button>
      </div>

      <Card className="border border-gray-200 shadow-sm">
        <CardContent className="p-5">
          <div className="flex items-center justify-between mb-4">
            <div className="relative w-64">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search requisitions..."
                className="pl-8"
                aria-label="Search requisitions"
              />
            </div>
            <Button variant="outline" size="sm">
              <Filter className="mr-2 h-4 w-4" />
              Filter
            </Button>
          </div>

          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Requisition ID</TableHead>
                  <TableHead>Title</TableHead>
                  <TableHead>Requester</TableHead>
                  <TableHead>Department</TableHead>
                  <TableHead>Total Amount</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Date Created</TableHead>
                  <TableHead className="w-[80px]">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {mockRequisitions.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-8">
                      <div className="flex flex-col items-center">
                        <FileText className="h-8 w-8 text-gray-400 mb-2" />
                        <p className="text-gray-500">No requisitions found</p>
                      </div>
                    </TableCell>
                  </TableRow>
                ) : (
                  mockRequisitions.map((req) => (
                    <TableRow key={req.id}>
                      <TableCell>
                        <Link to={`/requisitions/${req.id}`} className="text-blue-600 hover:underline">
                          {req.id}
                        </Link>
                      </TableCell>
                      <TableCell>{req.title}</TableCell>
                      <TableCell>{req.requester}</TableCell>
                      <TableCell>{req.department}</TableCell>
                      <TableCell>${req.totalAmount.toLocaleString()}</TableCell>
                      <TableCell>
                        <StatusBadge status={req.status} />
                      </TableCell>
                      <TableCell>{req.dateCreated}</TableCell>
                      <TableCell>
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="h-4 w-4" />
                          <span className="sr-only">Actions</span>
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Requisitions;
