import React, { useState } from 'react';
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from '../components/ui/card';
import { Button } from '../components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '../components/ui/select';
import { Input } from '../components/ui/input';
import { Link } from 'react-router-dom';
import { ArrowLeft, Save, Trash2 } from 'lucide-react';
import SimpleWorkflowDesigner from '../components/workflow/SimpleWorkflowDesigner';

// Sample workflow templates
const workflowTemplates = [
  {
    id: 'simple-approval',
    name: 'Simple Approval',
    description: 'Basic one-step approval process'
  },
  {
    id: 'multi-level-approval',
    name: 'Multi-Level Approval',
    description: 'Sequential approvals based on hierarchy'
  },
  {
    id: 'conditional-approval',
    name: 'Conditional Approval',
    description: 'Different approval paths based on amount, department, etc.'
  },
  {
    id: 'custom',
    name: 'Custom Workflow',
    description: 'Design your workflow from scratch'
  }
];

const WorkflowDesignerPage: React.FC = () => {
  const [selectedTemplate, setSelectedTemplate] = useState<string>('custom');
  const [workflowName, setWorkflowName] = useState<string>('New Workflow');

  return (
    <div className="container py-6 space-y-6">
      <div className="flex items-center gap-4">
        <Link to="/settings">
          <Button variant="outline" size="sm">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Settings
          </Button>
        </Link>
        <h1 className="text-2xl font-bold">Workflow Designer</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Workflow Templates</CardTitle>
          <CardDescription>
            Choose a pre-defined template or create your own custom workflow
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-4">
            <div className="w-1/3">
              <label htmlFor="workflowName" className="text-sm font-medium block mb-2">
                Workflow Name
              </label>
              <Input
                id="workflowName"
                value={workflowName}
                onChange={(e) => setWorkflowName(e.target.value)}
                placeholder="Enter workflow name"
              />
            </div>
            <div className="w-1/3">
              <label htmlFor="template" className="text-sm font-medium block mb-2">
                Workflow Template
              </label>
              <Select
                value={selectedTemplate}
                onValueChange={setSelectedTemplate}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select a template" />
                </SelectTrigger>
                <SelectContent>
                  {workflowTemplates.map((template) => (
                    <SelectItem key={template.id} value={template.id}>
                      {template.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="p-2 bg-muted rounded-md">
            <p className="text-sm text-muted-foreground mb-2">
              {workflowTemplates.find((t) => t.id === selectedTemplate)?.description || 'Create your custom workflow'}
            </p>
          </div>
        </CardContent>
      </Card>

      <SimpleWorkflowDesigner />

      <div className="flex justify-end gap-2">
        <Button variant="outline">
          <Trash2 className="mr-2 h-4 w-4" />
          Discard Changes
        </Button>
        <Button>
          <Save className="mr-2 h-4 w-4" />
          Save Workflow
        </Button>
      </div>
    </div>
  );
};

export default WorkflowDesignerPage;
