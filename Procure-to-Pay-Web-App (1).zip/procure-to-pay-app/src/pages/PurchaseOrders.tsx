import { useState } from 'react'
import { Link } from 'react-router-dom'
import {
  Table, TableHeader, TableBody, TableHead, TableRow, TableCell
} from '../components/ui/table'
import { Button } from '../components/ui/button'
import { Input } from '../components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card'
import {
  Search,
  Filter,
  MoreHorizontal,
  Plus,
  Eye,
  FileEdit,
  CheckCircle2,
  Clock,
  XCircle,
  Download,
  Printer,
  ArrowUpDown,
  ChevronDown,
  ArrowUp,
  ArrowDown
} from 'lucide-react'

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '../components/ui/dropdown-menu'

// Sample data
const PURCHASE_ORDERS = [
  {
    id: "PO-2023-1034",
    vendor: "ABC Corp",
    requester: "John Smith",
    date: "2023-06-12",
    total: 2450.00,
    status: "approved"
  },
  {
    id: "PO-2023-1033",
    vendor: "Staples Inc",
    requester: "Emily Johnson",
    date: "2023-06-11",
    total: 560.75,
    status: "pending"
  },
  {
    id: "PO-2023-1032",
    vendor: "Dell Technologies",
    requester: "Michael Brown",
    date: "2023-06-10",
    total: 4325.99,
    status: "approved"
  },
  {
    id: "PO-2023-1031",
    vendor: "Microsoft Corp",
    requester: "David Wilson",
    date: "2023-06-08",
    total: 1899.00,
    status: "rejected"
  },
  {
    id: "PO-2023-1030",
    vendor: "AV Solutions Inc",
    requester: "Sarah Miller",
    date: "2023-06-05",
    total: 3267.50,
    status: "approved"
  }
]

const PurchaseOrders = () => {
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedPOs, setSelectedPOs] = useState<string[]>([])
  const [sortedBy, setSortedBy] = useState<{ field: string, direction: 'asc' | 'desc' } | null>(null)
  const [filtersOpen, setFiltersOpen] = useState(false)

  // Filter POs based on search query
  const filteredPOs = PURCHASE_ORDERS.filter(po =>
    po.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
    po.vendor.toLowerCase().includes(searchQuery.toLowerCase()) ||
    po.requester.toLowerCase().includes(searchQuery.toLowerCase())
  )

  // Sort POs if needed
  const sortedPOs = [...filteredPOs].sort((a, b) => {
    if (!sortedBy) return 0;

    const fieldA = a[sortedBy.field as keyof typeof a];
    const fieldB = b[sortedBy.field as keyof typeof b];

    if (typeof fieldA === 'string' && typeof fieldB === 'string') {
      return sortedBy.direction === 'asc'
        ? fieldA.localeCompare(fieldB)
        : fieldB.localeCompare(fieldA);
    }

    if (typeof fieldA === 'number' && typeof fieldB === 'number') {
      return sortedBy.direction === 'asc'
        ? fieldA - fieldB
        : fieldB - fieldA;
    }

    return 0;
  });

  const handleSort = (field: string) => {
    setSortedBy(prev => {
      if (prev?.field === field) {
        return { field, direction: prev.direction === 'asc' ? 'desc' : 'asc' };
      }
      return { field, direction: 'asc' };
    });
  };

  const handleSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.checked) {
      setSelectedPOs(filteredPOs.map(po => po.id));
    } else {
      setSelectedPOs([]);
    }
  };

  const handleSelectPO = (poId: string) => {
    setSelectedPOs(prev => {
      if (prev.includes(poId)) {
        return prev.filter(id => id !== poId);
      } else {
        return [...prev, poId];
      }
    });
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'approved':
        return <CheckCircle2 className="h-4 w-4 text-success-600" />;
      case 'pending':
        return <Clock className="h-4 w-4 text-warning-600" />;
      case 'rejected':
        return <XCircle className="h-4 w-4 text-error-600" />;
      default:
        return null;
    }
  };

  // Stats for insights
  const approvedCount = PURCHASE_ORDERS.filter(po => po.status === 'approved').length;
  const pendingCount = PURCHASE_ORDERS.filter(po => po.status === 'pending').length;
  const rejectedCount = PURCHASE_ORDERS.filter(po => po.status === 'rejected').length;
  const totalValue = PURCHASE_ORDERS.reduce((acc, po) => acc + po.total, 0);

  return (
    <div className="container py-6 space-y-6 max-w-7xl mx-auto">
      {/* Header with improved visual hierarchy */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-2">
        <div>
          <h1 className="text-2xl font-semibold text-neutral-900 tracking-tight mb-1">Purchase Orders</h1>
          <p className="text-sm text-neutral-500">Manage and track your procurement documents</p>
        </div>
        <Button className="bg-primary-600 hover:bg-primary-700 text-white shadow-sm transition-colors h-10 px-4">
          <Plus className="mr-2 h-4 w-4" />
          Create Purchase Order
        </Button>
      </div>

      {/* Insights Cards with improved visual design */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <Card className="overflow-hidden border border-neutral-200 shadow-sm">
          <CardContent className="p-0">
            <div className="flex items-center h-full">
              <div className="bg-primary-50 p-4 flex items-center justify-center h-full">
                <Download className="h-6 w-6 text-primary-600" />
              </div>
              <div className="p-4 flex flex-col flex-1">
                <span className="text-xs font-medium text-neutral-500 uppercase tracking-wide mb-1">TOTAL VALUE</span>
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-bold text-neutral-900">
                    ${totalValue.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="overflow-hidden border border-neutral-200 shadow-sm">
          <CardContent className="p-0">
            <div className="h-full">
              <div className="p-4">
                <span className="text-xs font-medium text-neutral-500 uppercase tracking-wide mb-3 block">BY STATUS</span>
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-1.5">
                    <div className="h-3 w-3 rounded-full bg-success-500"></div>
                    <span className="text-sm font-medium">{approvedCount} Approved</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <div className="h-3 w-3 rounded-full bg-warning-500"></div>
                    <span className="text-sm font-medium">{pendingCount} Pending</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <div className="h-3 w-3 rounded-full bg-error-500"></div>
                    <span className="text-sm font-medium">{rejectedCount} Rejected</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="overflow-hidden border border-neutral-200 shadow-sm">
          <CardContent className="p-0">
            <div className="flex items-center h-full">
              <div className="bg-purple-50 p-4 flex items-center justify-center h-full">
                <Printer className="h-6 w-6 text-purple-600" />
              </div>
              <div className="p-4 flex flex-col flex-1">
                <span className="text-xs font-medium text-neutral-500 uppercase tracking-wide mb-1">RECENT ACTIVITY</span>
                <span className="text-sm font-medium">2 new orders this week</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Enhanced Search and Filter with better visual hierarchy */}
      <Card className="border border-neutral-200 shadow-sm">
        <CardContent className="p-5">
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
            <div className="relative grow w-full">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-neutral-400" />
              <Input
                type="search"
                placeholder="Search by PO number, vendor, or requester..."
                className="pl-9 w-full border-neutral-300 rounded-md h-10 text-sm"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            <div className="flex items-center gap-3 self-end">
              <Button
                variant="outline"
                className="h-10 border-neutral-300 text-neutral-700 hover:bg-neutral-50 gap-2"
                onClick={() => setFiltersOpen(!filtersOpen)}
              >
                <Filter className="h-4 w-4" />
                <span>Filter</span>
                <ChevronDown className={`h-4 w-4 transition-transform ${filtersOpen ? 'rotate-180' : ''}`} />
              </Button>

              {selectedPOs.length > 0 && (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      variant="outline"
                      className="h-10 border-neutral-300 text-neutral-700 hover:bg-neutral-50"
                    >
                      Batch Actions ({selectedPOs.length})
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="bg-white border border-neutral-200 shadow-md rounded-md">
                    <DropdownMenuItem className="text-sm text-neutral-700 hover:bg-neutral-50 cursor-pointer">
                      <CheckCircle2 className="mr-2 h-4 w-4 text-success-600" />
                      <span>Approve Selected</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem className="text-sm text-neutral-700 hover:bg-neutral-50 cursor-pointer">
                      <Download className="mr-2 h-4 w-4 text-primary-600" />
                      <span>Export Selected</span>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator className="my-1 bg-neutral-200" />
                    <DropdownMenuItem className="text-sm text-error-600 hover:bg-neutral-50 cursor-pointer">
                      <XCircle className="mr-2 h-4 w-4" />
                      <span>Cancel Selected</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              )}
            </div>
          </div>

          {/* Expandable filters panel */}
          {filtersOpen && (
            <div className="mt-4 pt-4 border-t border-neutral-200 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-neutral-700 mb-1">Status</label>
                <select className="w-full rounded-md border-neutral-300 h-10 text-sm focus:border-primary-500 focus:ring-primary-500">
                  <option value="">All Statuses</option>
                  <option value="approved">Approved</option>
                  <option value="pending">Pending</option>
                  <option value="rejected">Rejected</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-neutral-700 mb-1">Date Range</label>
                <select className="w-full rounded-md border-neutral-300 h-10 text-sm focus:border-primary-500 focus:ring-primary-500">
                  <option value="">All Time</option>
                  <option value="today">Today</option>
                  <option value="yesterday">Yesterday</option>
                  <option value="thisWeek">This Week</option>
                  <option value="thisMonth">This Month</option>
                  <option value="lastMonth">Last Month</option>
                  <option value="custom">Custom Range</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-neutral-700 mb-1">Vendor</label>
                <select className="w-full rounded-md border-neutral-300 h-10 text-sm focus:border-primary-500 focus:ring-primary-500">
                  <option value="">All Vendors</option>
                  <option value="abc">ABC Corp</option>
                  <option value="staples">Staples Inc</option>
                  <option value="dell">Dell Technologies</option>
                  <option value="microsoft">Microsoft Corp</option>
                  <option value="avsolutions">AV Solutions Inc</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-neutral-700 mb-1">Amount</label>
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    placeholder="Min"
                    className="rounded-md border-neutral-300 h-10 text-sm focus:border-primary-500 focus:ring-primary-500"
                  />
                  <span className="text-neutral-500">to</span>
                  <Input
                    type="number"
                    placeholder="Max"
                    className="rounded-md border-neutral-300 h-10 text-sm focus:border-primary-500 focus:ring-primary-500"
                  />
                </div>
              </div>
              <div className="col-span-full flex justify-end gap-2">
                <Button variant="outline" className="h-9 border-neutral-300 text-neutral-700 hover:bg-neutral-50">Reset</Button>
                <Button className="h-9 bg-primary-600 hover:bg-primary-700 text-white">Apply Filters</Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Purchase Orders Table with improved hierarchy and styling */}
      <Card className="border border-neutral-200 shadow-sm overflow-hidden">
        <CardHeader className="border-b border-neutral-200 bg-neutral-50 py-4 px-6">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold text-neutral-900">All Purchase Orders</CardTitle>

            {selectedPOs.length > 0 && (
              <div className="text-sm text-neutral-500">
                {selectedPOs.length} of {filteredPOs.length} selected
              </div>
            )}
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader className="bg-neutral-50">
                <TableRow className="border-b border-neutral-200">
                  <TableHead className="w-[40px] pl-6 py-3">
                    <input
                      type="checkbox"
                      className="h-4 w-4 rounded border-neutral-300 text-primary-600 focus:ring-primary-500"
                      checked={selectedPOs.length === filteredPOs.length && filteredPOs.length > 0}
                      onChange={handleSelectAll}
                    />
                  </TableHead>
                  <TableHead
                    className="w-[150px] py-3 text-neutral-700 text-sm font-medium cursor-pointer"
                    onClick={() => handleSort('id')}
                  >
                    <div className="flex items-center">
                      PO Number
                      {sortedBy?.field === 'id' && (
                        sortedBy.direction === 'asc' ?
                          <ArrowUp className="ml-1 h-4 w-4 text-neutral-500" /> :
                          <ArrowDown className="ml-1 h-4 w-4 text-neutral-500" />
                      )}
                      {sortedBy?.field !== 'id' && <ArrowUpDown className="ml-1 h-4 w-4 text-neutral-400" />}
                    </div>
                  </TableHead>
                  <TableHead
                    className="py-3 text-neutral-700 text-sm font-medium cursor-pointer"
                    onClick={() => handleSort('vendor')}
                  >
                    <div className="flex items-center">
                      Vendor
                      {sortedBy?.field === 'vendor' && (
                        sortedBy.direction === 'asc' ?
                          <ArrowUp className="ml-1 h-4 w-4 text-neutral-500" /> :
                          <ArrowDown className="ml-1 h-4 w-4 text-neutral-500" />
                      )}
                      {sortedBy?.field !== 'vendor' && <ArrowUpDown className="ml-1 h-4 w-4 text-neutral-400" />}
                    </div>
                  </TableHead>
                  <TableHead
                    className="py-3 text-neutral-700 text-sm font-medium cursor-pointer"
                    onClick={() => handleSort('requester')}
                  >
                    <div className="flex items-center">
                      Requester
                      {sortedBy?.field === 'requester' && (
                        sortedBy.direction === 'asc' ?
                          <ArrowUp className="ml-1 h-4 w-4 text-neutral-500" /> :
                          <ArrowDown className="ml-1 h-4 w-4 text-neutral-500" />
                      )}
                      {sortedBy?.field !== 'requester' && <ArrowUpDown className="ml-1 h-4 w-4 text-neutral-400" />}
                    </div>
                  </TableHead>
                  <TableHead
                    className="py-3 text-neutral-700 text-sm font-medium cursor-pointer"
                    onClick={() => handleSort('date')}
                  >
                    <div className="flex items-center">
                      Date
                      {sortedBy?.field === 'date' && (
                        sortedBy.direction === 'asc' ?
                          <ArrowUp className="ml-1 h-4 w-4 text-neutral-500" /> :
                          <ArrowDown className="ml-1 h-4 w-4 text-neutral-500" />
                      )}
                      {sortedBy?.field !== 'date' && <ArrowUpDown className="ml-1 h-4 w-4 text-neutral-400" />}
                    </div>
                  </TableHead>
                  <TableHead
                    className="py-3 text-neutral-700 text-sm font-medium text-right cursor-pointer"
                    onClick={() => handleSort('total')}
                  >
                    <div className="flex items-center justify-end">
                      Total
                      {sortedBy?.field === 'total' && (
                        sortedBy.direction === 'asc' ?
                          <ArrowUp className="ml-1 h-4 w-4 text-neutral-500" /> :
                          <ArrowDown className="ml-1 h-4 w-4 text-neutral-500" />
                      )}
                      {sortedBy?.field !== 'total' && <ArrowUpDown className="ml-1 h-4 w-4 text-neutral-400" />}
                    </div>
                  </TableHead>
                  <TableHead
                    className="py-3 text-neutral-700 text-sm font-medium cursor-pointer"
                    onClick={() => handleSort('status')}
                  >
                    <div className="flex items-center">
                      Status
                      {sortedBy?.field === 'status' && (
                        sortedBy.direction === 'asc' ?
                          <ArrowUp className="ml-1 h-4 w-4 text-neutral-500" /> :
                          <ArrowDown className="ml-1 h-4 w-4 text-neutral-500" />
                      )}
                      {sortedBy?.field !== 'status' && <ArrowUpDown className="ml-1 h-4 w-4 text-neutral-400" />}
                    </div>
                  </TableHead>
                  <TableHead className="w-[100px] text-right pr-6 py-3 text-neutral-700 text-sm font-medium">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sortedPOs.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-12 text-neutral-500">
                      <div className="flex flex-col items-center justify-center">
                        <Search className="h-12 w-12 text-neutral-300 mb-3" />
                        <p className="text-lg font-medium text-neutral-700 mb-1">No purchase orders found</p>
                        <p className="text-neutral-500 max-w-md">Try adjusting your search or filter criteria to find what you're looking for.</p>
                      </div>
                    </TableCell>
                  </TableRow>
                ) : (
                  sortedPOs.map(po => (
                    <TableRow key={po.id} className="hover:bg-neutral-50 border-b border-neutral-200 h-[60px]">
                      <TableCell className="pl-6">
                        <input
                          type="checkbox"
                          className="h-4 w-4 rounded border-neutral-300 text-primary-600 focus:ring-primary-500"
                          checked={selectedPOs.includes(po.id)}
                          onChange={() => handleSelectPO(po.id)}
                        />
                      </TableCell>
                      <TableCell className="font-medium text-primary-700">
                        <Link to={`/purchase-orders/${po.id}`} className="hover:underline hover:text-primary-800 flex items-center transition-colors">
                          {po.id}
                        </Link>
                      </TableCell>
                      <TableCell className="text-neutral-800 font-medium">{po.vendor}</TableCell>
                      <TableCell className="text-neutral-800">{po.requester}</TableCell>
                      <TableCell className="text-neutral-800">{po.date}</TableCell>
                      <TableCell className="text-right font-medium text-neutral-800">
                        ${po.total.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}
                      </TableCell>
                      <TableCell>
                        <div className={`
                          inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium
                          ${po.status === 'approved' ? 'bg-success-50 text-success-800' :
                            po.status === 'pending' ? 'bg-warning-50 text-warning-800' :
                            'bg-error-50 text-error-800'}
                        `}>
                          {getStatusIcon(po.status)}
                          {po.status.charAt(0).toUpperCase() + po.status.slice(1)}
                        </div>
                      </TableCell>
                      <TableCell className="text-right pr-6">
                        <div className="flex items-center justify-end gap-1">
                          <Link to={`/purchase-orders/${po.id}`}>
                            <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full text-neutral-500 hover:text-primary-700 hover:bg-primary-50">
                              <Eye className="h-4 w-4" />
                              <span className="sr-only">View</span>
                            </Button>
                          </Link>
                          <Link to={`/purchase-orders/${po.id}/edit`}>
                            <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full text-neutral-500 hover:text-primary-700 hover:bg-primary-50">
                              <FileEdit className="h-4 w-4" />
                              <span className="sr-only">Edit</span>
                            </Button>
                          </Link>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full text-neutral-500 hover:text-primary-700 hover:bg-primary-50">
                                <MoreHorizontal className="h-4 w-4" />
                                <span className="sr-only">More</span>
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" className="bg-white border border-neutral-200 shadow-md rounded-md w-48">
                              <DropdownMenuItem className="text-sm text-neutral-700 hover:bg-neutral-50 cursor-pointer">
                                <Download className="mr-2 h-4 w-4 text-neutral-500" />
                                Download PDF
                              </DropdownMenuItem>
                              <DropdownMenuItem className="text-sm text-neutral-700 hover:bg-neutral-50 cursor-pointer">
                                <Printer className="mr-2 h-4 w-4 text-neutral-500" />
                                Print
                              </DropdownMenuItem>
                              <DropdownMenuSeparator className="my-1 bg-neutral-200" />
                              <DropdownMenuItem className="text-sm text-error-600 hover:bg-neutral-50 cursor-pointer">
                                <XCircle className="mr-2 h-4 w-4" />
                                Cancel
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
          {/* Pagination */}
          <div className="py-4 px-6 border-t border-neutral-200 bg-white flex items-center justify-between">
            <div className="text-sm text-neutral-600">
              Showing <span className="font-medium">{sortedPOs.length}</span> of <span className="font-medium">{PURCHASE_ORDERS.length}</span> purchase orders
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                className="h-8 text-neutral-700 border-neutral-300 hover:bg-neutral-50 disabled:opacity-50"
                disabled={true}
              >
                Previous
              </Button>
              <span className="flex h-8 w-8 items-center justify-center rounded-md border border-neutral-300 bg-white text-sm font-medium text-neutral-900">1</span>
              <Button
                variant="outline"
                size="sm"
                className="h-8 text-neutral-700 border-neutral-300 hover:bg-neutral-50 disabled:opacity-50"
                disabled={true}
              >
                Next
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default PurchaseOrders
