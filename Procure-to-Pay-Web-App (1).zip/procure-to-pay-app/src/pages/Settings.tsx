import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Tabs, TabsList, TabsTrigger } from '../components/ui/tabs';
import {
  Settings as SettingsIcon,
  Users,
  Workflow,
  Globe,
  ShieldAlert,
  Bell
} from 'lucide-react';

const Settings: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();

  // Get the current tab from the URL
  const getCurrentTab = () => {
    const path = location.pathname;
    if (path.includes('/workflows')) return 'workflows';
    if (path.includes('/users')) return 'users';
    if (path.includes('/integrations')) return 'integrations';
    if (path.includes('/security')) return 'security';
    if (path.includes('/notifications')) return 'notifications';
    return 'general';
  };

  const handleTabChange = (value: string) => {
    switch(value) {
      case 'workflows':
        navigate('/settings/workflows');
        break;
      case 'users':
        navigate('/settings/users');
        break;
      case 'integrations':
        navigate('/settings/integrations');
        break;
      case 'security':
        navigate('/settings/security');
        break;
      case 'notifications':
        navigate('/settings/notifications');
        break;
      default:
        navigate('/settings/general');
    }
  };

  return (
    <div className="container py-6 space-y-6">
      <div className="flex items-center gap-2">
        <SettingsIcon className="h-6 w-6" />
        <h1 className="text-2xl font-bold">Settings</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>System Configuration</CardTitle>
          <CardDescription>
            Configure system-wide settings and preferences
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs
            value={getCurrentTab()}
            onValueChange={handleTabChange}
            className="w-full"
          >
            <TabsList className="grid grid-cols-6 mb-8">
              <TabsTrigger value="general" className="flex items-center gap-2">
                <SettingsIcon className="h-4 w-4" />
                <span className="hidden sm:inline">General</span>
              </TabsTrigger>
              <TabsTrigger value="workflows" className="flex items-center gap-2">
                <Workflow className="h-4 w-4" />
                <span className="hidden sm:inline">Workflows</span>
              </TabsTrigger>
              <TabsTrigger value="users" className="flex items-center gap-2">
                <Users className="h-4 w-4" />
                <span className="hidden sm:inline">Users</span>
              </TabsTrigger>
              <TabsTrigger value="integrations" className="flex items-center gap-2">
                <Globe className="h-4 w-4" />
                <span className="hidden sm:inline">Integrations</span>
              </TabsTrigger>
              <TabsTrigger value="security" className="flex items-center gap-2">
                <ShieldAlert className="h-4 w-4" />
                <span className="hidden sm:inline">Security</span>
              </TabsTrigger>
              <TabsTrigger value="notifications" className="flex items-center gap-2">
                <Bell className="h-4 w-4" />
                <span className="hidden sm:inline">Notifications</span>
              </TabsTrigger>
            </TabsList>
          </Tabs>

          <div className="mt-4 text-center text-muted-foreground p-8">
            <p>Select a settings category from the tabs above</p>
            <p className="text-sm mt-2">or go directly to <a href="/settings/workflows" className="text-blue-600 font-medium hover:underline">Workflow Designer</a></p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Settings;
