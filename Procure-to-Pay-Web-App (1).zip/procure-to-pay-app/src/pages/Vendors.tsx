import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import {
  Table, TableHeader, TableBody, TableHead, TableRow, TableCell
} from '../components/ui/table'
import { Button } from '../components/ui/button'
import { Input } from '../components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card'
import { Search, Filter, Users, MoreHorizontal, Plus, Building, Phone, Mail, DollarSign } from 'lucide-react'

// Mock data for vendors
const mockVendors = [
  {
    id: 'V-001',
    name: 'Microsoft Corp',
    category: 'Software & Licensing',
    address: '1 Microsoft Way, Redmond, WA 98052',
    contactPerson: 'Sarah Wilson',
    email: 'sarah.wilson@microsoft.com',
    phone: '(425) 882-8080',
    status: 'Active',
    totalSpend: '$125,800.00',
    paymentTerms: 'Net 30',
  },
  {
    id: 'V-002',
    name: 'Dell Technologies',
    category: 'Hardware & Equipment',
    address: '1 Dell Way, Round Rock, TX 78682',
    contactPerson: 'Michael Chen',
    email: 'michael.chen@dell.com',
    phone: '(800) 624-9897',
    status: 'Active',
    totalSpend: '$83,250.00',
    paymentTerms: 'Net 45',
  },
  {
    id: 'V-003',
    name: 'Staples Inc',
    category: 'Office Supplies',
    address: '500 Staples Drive, Framingham, MA 01702',
    contactPerson: 'Emily Brown',
    email: 'emily.brown@staples.com',
    phone: '(800) 378-2753',
    status: 'Active',
    totalSpend: '$32,450.00',
    paymentTerms: 'Net 30',
  },
  {
    id: 'V-004',
    name: 'AV Solutions Inc',
    category: 'Audio/Visual Equipment',
    address: '123 Tech Blvd, San Jose, CA 95134',
    contactPerson: 'David Martinez',
    email: 'dmartinez@avsolutions.com',
    phone: '(408) 555-7890',
    status: 'Active',
    totalSpend: '$47,850.00',
    paymentTerms: 'Net 30',
  },
  {
    id: 'V-005',
    name: 'Food & Co',
    category: 'Catering & Food Services',
    address: '789 Culinary Ave, Chicago, IL 60614',
    contactPerson: 'Amanda Liu',
    email: 'amanda@foodandco.com',
    phone: '(312) 555-1234',
    status: 'Inactive',
    totalSpend: '$18,750.00',
    paymentTerms: 'Net 15',
  },
];

const StatusBadge = ({ status }: { status: string }) => {
  const bgColor = status === 'Active'
    ? 'bg-green-100 text-green-800'
    : 'bg-gray-100 text-gray-800';

  return (
    <span className={`px-2 py-1 rounded-full text-xs font-medium ${bgColor}`}>
      {status}
    </span>
  );
};

const VendorCard = ({ vendor }: { vendor: typeof mockVendors[0] }) => {
  return (
    <Card className="h-full">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <CardTitle className="text-lg font-bold">{vendor.name}</CardTitle>
          <StatusBadge status={vendor.status} />
        </div>
        <p className="text-sm text-muted-foreground">{vendor.category}</p>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          <div className="flex items-start gap-2">
            <Building className="h-4 w-4 mt-1 text-muted-foreground shrink-0" />
            <span className="text-sm">{vendor.address}</span>
          </div>
          <div className="flex items-center gap-2">
            <Users className="h-4 w-4 text-muted-foreground shrink-0" />
            <span className="text-sm">{vendor.contactPerson}</span>
          </div>
          <div className="flex items-center gap-2">
            <Mail className="h-4 w-4 text-muted-foreground shrink-0" />
            <span className="text-sm">{vendor.email}</span>
          </div>
          <div className="flex items-center gap-2">
            <Phone className="h-4 w-4 text-muted-foreground shrink-0" />
            <span className="text-sm">{vendor.phone}</span>
          </div>
          <div className="flex items-center gap-2 mt-3 pt-3 border-t">
            <DollarSign className="h-4 w-4 text-muted-foreground shrink-0" />
            <div>
              <div className="text-sm font-medium">Total Spend: {vendor.totalSpend}</div>
              <div className="text-xs text-muted-foreground">Payment Terms: {vendor.paymentTerms}</div>
            </div>
          </div>
        </div>
        <div className="mt-4">
          <Link
            to={`/vendors/${vendor.id}`}
            className="text-sm text-primary hover:underline"
          >
            View details
          </Link>
        </div>
      </CardContent>
    </Card>
  );
};

const Vendors: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [viewMode, setViewMode] = useState<'table' | 'grid'>('table');

  const filteredVendors = mockVendors.filter(vendor =>
    vendor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    vendor.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
    vendor.contactPerson.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Vendors</h1>
          <p className="text-muted-foreground">
            Manage supplier information and relationships.
          </p>
        </div>
        <div>
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            Add New Vendor
          </Button>
        </div>
      </div>

      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <div className="relative w-64">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search vendors..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <Button variant="outline" size="sm">
                <Filter className="mr-2 h-4 w-4" />
                Filter
              </Button>
            </div>

            <div className="flex items-center space-x-2">
              <Button
                variant={viewMode === 'table' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('table')}
              >
                Table
              </Button>
              <Button
                variant={viewMode === 'grid' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('grid')}
              >
                Grid
              </Button>
            </div>
          </div>

          {viewMode === 'table' ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Vendor</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Contact Person</TableHead>
                  <TableHead>Contact Info</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Total Spend</TableHead>
                  <TableHead>Payment Terms</TableHead>
                  <TableHead className="w-[80px]"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredVendors.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-8">
                      <div className="flex flex-col items-center">
                        <Users className="h-8 w-8 text-muted-foreground mb-2" />
                        <p className="text-muted-foreground">No vendors found</p>
                      </div>
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredVendors.map((vendor) => (
                    <TableRow key={vendor.id}>
                      <TableCell>
                        <Link to={`/vendors/${vendor.id}`} className="font-medium hover:underline">
                          {vendor.name}
                        </Link>
                      </TableCell>
                      <TableCell>{vendor.category}</TableCell>
                      <TableCell>{vendor.contactPerson}</TableCell>
                      <TableCell>
                        <div className="text-sm">{vendor.email}</div>
                        <div className="text-sm text-muted-foreground">{vendor.phone}</div>
                      </TableCell>
                      <TableCell>
                        <StatusBadge status={vendor.status} />
                      </TableCell>
                      <TableCell>{vendor.totalSpend}</TableCell>
                      <TableCell>{vendor.paymentTerms}</TableCell>
                      <TableCell>
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredVendors.length === 0 ? (
                <div className="col-span-full text-center py-8">
                  <Users className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                  <p className="text-muted-foreground">No vendors found</p>
                </div>
              ) : (
                filteredVendors.map((vendor) => (
                  <VendorCard key={vendor.id} vendor={vendor} />
                ))
              )}
            </div>
          )}

          <div className="flex items-center justify-end mt-4 space-x-2">
            <Button variant="outline" size="sm" disabled>
              Previous
            </Button>
            <Button variant="outline" size="sm">
              Next
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default Vendors
