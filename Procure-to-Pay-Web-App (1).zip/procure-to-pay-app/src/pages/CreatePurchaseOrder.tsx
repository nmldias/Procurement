import React from 'react';
import PurchaseOrderForm, { PurchaseOrderData } from '../components/purchase-orders/PurchaseOrderForm';
import { Button } from '../components/ui/button';
import { ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';

const CreatePurchaseOrder: React.FC = () => {
  const handlePurchaseOrderSubmit = (data: PurchaseOrderData) => {
    console.log('Purchase Order Submitted:', data);
    // Here you would typically save to a database or API
  };

  return (
    <div className="container py-6 space-y-6">
      <div className="flex items-center gap-4">
        <Link to="/purchase-orders">
          <Button variant="outline" size="sm">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Purchase Orders
          </Button>
        </Link>
        <h1 className="text-2xl font-bold">Create Purchase Order</h1>
      </div>

      <PurchaseOrderForm onSubmit={handlePurchaseOrderSubmit} />
    </div>
  );
};

export default CreatePurchaseOrder;
