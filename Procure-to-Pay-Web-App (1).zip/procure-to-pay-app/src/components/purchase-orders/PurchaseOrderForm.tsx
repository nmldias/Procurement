import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle
} from '../ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import {
  FileText,
  ListChecks,
  Paperclip,
  Settings
} from 'lucide-react';
import SimpleWorkflowDesigner from '../workflow/SimpleWorkflowDesigner';

export interface PurchaseOrderData {
  poNumber: string;
  date: string;
  vendor?: string;
  requester?: string;
  department?: string;
  lineItems?: Array<{
    description: string;
    quantity: number;
    unitPrice: number;
    total: number;
  }>;
  workflowNodes?: Array<{
    id: string;
    type: string;
    label: string;
  }>;
  attachments?: string[];
  notes?: string;
  status?: string;
}

interface PurchaseOrderFormProps {
  onSubmit?: (data: PurchaseOrderData) => void;
}

const PurchaseOrderForm: React.FC<PurchaseOrderFormProps> = ({ onSubmit }) => {
  const [activeTab, setActiveTab] = useState('details');

  const handleSubmit = () => {
    if (onSubmit) {
      const formData: PurchaseOrderData = {
        poNumber: 'PO-2023-1042',
        date: new Date().toISOString(),
        vendor: 'ABC Corp',
        requester: 'John Smith',
        department: 'IT',
        lineItems: [
          {
            description: 'Sample Item',
            quantity: 1,
            unitPrice: 100,
            total: 100
          }
        ],
        notes: '',
        status: ''
      };
      onSubmit(formData);
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Purchase Order</CardTitle>
        <CardDescription>
          Create a new purchase order or edit an existing one
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs
          defaultValue="details"
          value={activeTab}
          onValueChange={setActiveTab}
          className="w-full"
        >
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="details" className="flex items-center">
              <FileText className="mr-2 h-4 w-4" />
              PO Details
            </TabsTrigger>
            <TabsTrigger value="lineItems" className="flex items-center">
              <ListChecks className="mr-2 h-4 w-4" />
              Line Items
            </TabsTrigger>
            <TabsTrigger value="approvals" className="flex items-center">
              <Settings className="mr-2 h-4 w-4" />
              Approval Workflow
            </TabsTrigger>
            <TabsTrigger value="attachments" className="flex items-center">
              <Paperclip className="mr-2 h-4 w-4" />
              Attachments
            </TabsTrigger>
          </TabsList>

          {/* Details Tab */}
          <TabsContent value="details" className="space-y-4 mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium">PO Number</label>
                <Input value="PO-2023-1042" disabled />
                <p className="text-xs text-muted-foreground mt-1">
                  Auto-generated purchase order number
                </p>
              </div>

              <div>
                <label className="text-sm font-medium">Date</label>
                <Input type="date" />
              </div>

              <div>
                <label className="text-sm font-medium">Vendor</label>
                <Input placeholder="Select vendor" />
              </div>

              <div>
                <label className="text-sm font-medium">Requester</label>
                <Input placeholder="Select requester" />
              </div>
            </div>

            <div className="flex justify-between pt-4">
              <Button
                type="button"
                variant="outline"
              >
                Cancel
              </Button>
              <Button
                type="button"
                onClick={() => setActiveTab("lineItems")}
              >
                Next: Line Items
              </Button>
            </div>
          </TabsContent>

          {/* Line Items Tab */}
          <TabsContent value="lineItems" className="space-y-4 mt-4">
            <div className="rounded-md border p-4">
              <p className="text-center text-muted-foreground mb-4">Line items section</p>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                  <label className="text-sm font-medium">Description</label>
                  <Input placeholder="Item description" />
                </div>
                <div>
                  <label className="text-sm font-medium">Quantity</label>
                  <Input type="number" min="1" />
                </div>
                <div>
                  <label className="text-sm font-medium">Unit Price</label>
                  <Input type="number" min="0" step="0.01" />
                </div>
                <div>
                  <label className="text-sm font-medium">Total</label>
                  <Input type="number" disabled value="0.00" />
                </div>
              </div>
            </div>

            <div className="flex justify-between pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => setActiveTab("details")}
              >
                Previous: Details
              </Button>
              <Button
                type="button"
                onClick={() => setActiveTab("approvals")}
              >
                Next: Approval Workflow
              </Button>
            </div>
          </TabsContent>

          {/* Approvals Tab */}
          <TabsContent value="approvals" className="space-y-4 mt-4">
            <div className="p-4 rounded-md border">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium">Approval Workflow</h3>
                <Link to="/settings/workflows" className="text-sm text-blue-600 hover:underline flex items-center">
                  <Settings className="h-4 w-4 mr-1" />
                  Manage Workflow Templates
                </Link>
              </div>
              <p className="text-sm text-muted-foreground mb-4">
                Design the approval workflow for this purchase order. Add approval nodes and define conditions as needed.
              </p>
              <SimpleWorkflowDesigner />
            </div>

            <div className="flex justify-between pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => setActiveTab("lineItems")}
              >
                Previous: Line Items
              </Button>
              <Button
                type="button"
                onClick={() => setActiveTab("attachments")}
              >
                Next: Attachments
              </Button>
            </div>
          </TabsContent>

          {/* Attachments Tab */}
          <TabsContent value="attachments" className="space-y-4 mt-4">
            <div className="p-4 rounded-md border">
              <h3 className="text-lg font-medium mb-4">Attachments</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Add supporting documents such as quotes, specifications, or other relevant files.
              </p>
              <div className="flex items-center justify-center w-full">
                <label
                  htmlFor="file-upload"
                  className="flex flex-col items-center justify-center w-full h-64 border-2 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100"
                >
                  <div className="flex flex-col items-center justify-center pt-5 pb-6">
                    <Paperclip className="w-8 h-8 mb-4 text-gray-500" />
                    <p className="mb-2 text-sm text-gray-500">
                      <span className="font-semibold">Click to upload</span> or drag and drop
                    </p>
                    <p className="text-xs text-gray-500">
                      PDF, Word, Excel, or image files (max. 10MB)
                    </p>
                  </div>
                  <input id="file-upload" type="file" className="hidden" />
                </label>
              </div>
            </div>

            <div className="flex justify-between pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => setActiveTab("approvals")}
              >
                Previous: Approvals
              </Button>
              <Button type="button" onClick={handleSubmit}>
                Save Purchase Order
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default PurchaseOrderForm;
