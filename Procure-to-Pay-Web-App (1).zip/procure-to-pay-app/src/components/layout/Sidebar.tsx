import React, { useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { cn } from '../../lib/utils'
import {
  Home,
  FileText,
  ShoppingCart,
  Receipt,
  Users,
  BarChart3,
  Settings,
  Search,
  Clock,
  CheckCircle,
  AlertTriangle,
  ChevronDown
} from 'lucide-react'

interface NavItemProps {
  href: string;
  icon: React.ElementType;
  label: string;
  isActive?: boolean;
  badge?: number | string;
  badgeColor?: string;
  onClick?: () => void;
}

const NavItem: React.FC<NavItemProps> = ({
  href,
  icon: Icon,
  label,
  isActive,
  badge,
  badgeColor = "bg-blue-500",
  onClick
}) => {
  return (
    <Link
      to={href}
      className={cn(
        "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors relative",
        isActive
          ? "bg-blue-50 text-blue-700"
          : "text-gray-700 hover:bg-gray-100 hover:text-gray-900"
      )}
      onClick={onClick}
    >
      <Icon className="h-5 w-5 flex-shrink-0" />
      <span>{label}</span>
      {badge && (
        <span className={`${badgeColor} text-white text-xs font-semibold ml-auto py-0.5 px-1.5 rounded-full`}>
          {badge}
        </span>
      )}
    </Link>
  )
}

interface NavGroupProps {
  title: string;
  children: React.ReactNode;
  defaultOpen?: boolean;
}

const NavGroup: React.FC<NavGroupProps> = ({ title, children, defaultOpen = true }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="mb-4">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between px-3 py-1 text-xs font-semibold text-gray-500 uppercase tracking-wider"
      >
        {title}
        <ChevronDown
          className={cn(
            "h-4 w-4 transition-transform",
            isOpen ? "transform rotate-180" : ""
          )}
        />
      </button>
      {isOpen && <div className="mt-1 space-y-1">{children}</div>}
    </div>
  )
}

interface SidebarProps {
  className?: string
}

const Sidebar: React.FC<SidebarProps> = ({ className }) => {
  const location = useLocation()

  return (
    <aside className={cn("w-64 shrink-0 border-r border-gray-200 bg-white h-screen overflow-y-auto", className)}>
      <div className="flex flex-col h-full">
        <div className="p-4">
          <NavGroup title="Main">
            <NavItem
              href="/"
              icon={Home}
              label="Dashboard"
              isActive={location.pathname === '/'}
            />
            <NavItem
              href="/requisitions"
              icon={FileText}
              label="Requisitions"
              isActive={location.pathname === '/requisitions'}
              badge="12"
            />
            <NavItem
              href="/purchase-orders"
              icon={ShoppingCart}
              label="Purchase Orders"
              isActive={location.pathname.includes('/purchase-orders') || location.pathname.includes('/create-purchase-order')}
              badge="5"
            />
            <NavItem
              href="/invoices"
              icon={Receipt}
              label="Invoices"
              isActive={location.pathname === '/invoices'}
            />
            <NavItem
              href="/vendors"
              icon={Users}
              label="Vendors"
              isActive={location.pathname === '/vendors'}
            />
            <NavItem
              href="/reports"
              icon={BarChart3}
              label="Reports"
              isActive={location.pathname === '/reports'}
            />
          </NavGroup>

          <NavGroup title="Approvals" defaultOpen={false}>
            <NavItem
              href="/awaiting-approval"
              icon={Clock}
              label="Awaiting Approval"
              isActive={location.pathname === '/awaiting-approval'}
              badge="27"
              badgeColor="bg-amber-500"
            />
            <NavItem
              href="/approved"
              icon={CheckCircle}
              label="Approved"
              isActive={location.pathname === '/approved'}
            />
            <NavItem
              href="/exceptions"
              icon={AlertTriangle}
              label="Exceptions"
              isActive={location.pathname === '/exceptions'}
              badge="3"
              badgeColor="bg-red-500"
            />
          </NavGroup>

          <NavGroup title="System" defaultOpen={false}>
            <NavItem
              href="/settings"
              icon={Settings}
              label="Settings"
              isActive={location.pathname.includes('/settings')}
            />
            <NavItem
              href="/search"
              icon={Search}
              label="Advanced Search"
              isActive={location.pathname === '/search'}
            />
          </NavGroup>
        </div>

        <div className="mt-auto p-4 border-t border-gray-200">
          <div className="bg-blue-50 rounded-md p-3 text-sm text-blue-700">
            <h4 className="font-medium mb-1">Need help?</h4>
            <p className="text-xs text-blue-600">
              Check our <a href="#" className="underline">documentation</a> or contact <a href="#" className="underline">support</a>.
            </p>
          </div>
        </div>
      </div>
    </aside>
  )
}

export default Sidebar
