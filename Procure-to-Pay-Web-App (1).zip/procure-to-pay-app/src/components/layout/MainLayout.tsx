import React from 'react'
import { Outlet, useLocation } from 'react-router-dom'
import Sidebar from './Sidebar'
import Header from './Header'
import { ChevronRight } from 'lucide-react'

// Mapping routes to display names for breadcrumbs
const routeNames: Record<string, string> = {
  '': 'Dashboard',
  'requisitions': 'Requisitions',
  'purchase-orders': 'Purchase Orders',
  'create-purchase-order': 'Create Purchase Order',
  'invoices': 'Invoices',
  'vendors': 'Vendors',
  'reports': 'Reports',
  'settings': 'Settings',
  'settings/workflows': 'Workflow Designer'
}

const MainLayout: React.FC = () => {
  const location = useLocation()

  // Generate breadcrumbs based on current path
  const generateBreadcrumbs = () => {
    const pathnames = location.pathname.split('/').filter((path) => path)

    if (pathnames.length === 0) {
      return [{ name: 'Dashboard', path: '/' }]
    }

    return pathnames.map((value, index) => {
      const path = `/${pathnames.slice(0, index + 1).join('/')}`
      const name = routeNames[value] || value.charAt(0).toUpperCase() + value.slice(1)
      return { name, path }
    })
  }

  const breadcrumbs = generateBreadcrumbs()

  return (
    <div className="flex h-screen overflow-hidden bg-white">
      <Sidebar />
      <div className="flex flex-col flex-1 overflow-hidden">
        <Header />

        {/* Breadcrumbs */}
        <div className="bg-gray-50 px-6 py-2">
          <div className="flex items-center text-sm text-gray-500">
            {breadcrumbs.map((breadcrumb, index) => (
              <React.Fragment key={breadcrumb.path}>
                {index > 0 && <ChevronRight className="h-4 w-4 mx-2 text-gray-400" />}
                <span className={index === breadcrumbs.length - 1 ? 'font-medium text-gray-900' : ''}>
                  {breadcrumb.name}
                </span>
              </React.Fragment>
            ))}
          </div>
        </div>

        <main className="flex-1 overflow-auto bg-gray-50">
          <Outlet />
        </main>
      </div>
    </div>
  )
}

export default MainLayout
