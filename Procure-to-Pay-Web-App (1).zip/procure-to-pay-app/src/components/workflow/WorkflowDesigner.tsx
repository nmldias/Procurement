import React, { useState, useCallback, useMemo } from 'react';
import ReactFlow, {
  Background,
  Controls,
  MiniMap,
  ReactFlowProvider,
  Panel,
  addEdge,
  useNodesState,
  useEdgesState,
  Edge,
  Connection,
  Node,
  NodeTypes,
} from 'reactflow';
import 'reactflow/dist/style.css';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Save, FileDown, FileUp, Trash2 } from 'lucide-react';
import StartNode from './nodes/StartNode';
import ApprovalNode from './nodes/ApprovalNode';
import ConditionalNode from './nodes/ConditionalNode';
import ActionNode from './nodes/ActionNode';
import EndNode from './nodes/EndNode';

const nodeTypes: NodeTypes = {
  startNode: StartNode,
  approvalNode: ApprovalNode,
  conditionalNode: ConditionalNode,
  actionNode: ActionNode,
  endNode: EndNode,
};

type WorkflowDesignerProps = {
  initialNodes?: Node[];
  initialEdges?: Edge[];
  onSave?: (nodes: Node[], edges: Edge[]) => void;
};

const defaultNodes: Node[] = [
  {
    id: 'start-1',
    type: 'startNode',
    position: { x: 250, y: 5 },
    data: { label: 'Start' },
  },
];

const WorkflowDesigner: React.FC<WorkflowDesignerProps> = ({
  initialNodes = defaultNodes,
  initialEdges = [],
  onSave,
}) => {
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);
  const [selectedNodeType, setSelectedNodeType] = useState<string | null>(null);

  const onConnect = useCallback(
    (params: Edge | Connection) => setEdges((eds) => addEdge(params, eds)),
    [setEdges]
  );

  const handleAddNode = useCallback(
    (type: string) => {
      setSelectedNodeType(type);
    },
    []
  );

  const handleSaveWorkflow = useCallback(() => {
    if (onSave) {
      onSave(nodes, edges);
    }
  }, [nodes, edges, onSave]);

  const handlePaneClick = useCallback(
    (event: React.MouseEvent) => {
      if (selectedNodeType) {
        const reactFlowBounds = document.querySelector('.react-flow')?.getBoundingClientRect();
        if (reactFlowBounds) {
          const position = {
            x: event.clientX - reactFlowBounds.left,
            y: event.clientY - reactFlowBounds.top,
          };

          const newNode: Node = {
            id: `${selectedNodeType}-${Date.now()}`,
            type: selectedNodeType,
            position,
            data: { label: getNodeDefaultLabel(selectedNodeType) },
          };

          setNodes((nds) => nds.concat(newNode));
          setSelectedNodeType(null);
        }
      }
    },
    [selectedNodeType, setNodes]
  );

  const getNodeDefaultLabel = (type: string): string => {
    switch (type) {
      case 'startNode':
        return 'Start';
      case 'approvalNode':
        return 'Approval';
      case 'conditionalNode':
        return 'Condition';
      case 'actionNode':
        return 'Action';
      case 'endNode':
        return 'End';
      default:
        return 'Node';
    }
  };

  const nodeButtons = useMemo(
    () => [
      {
        type: 'approvalNode',
        color: 'bg-blue-500',
        label: 'Approval',
      },
      {
        type: 'conditionalNode',
        color: 'bg-amber-500',
        label: 'Condition',
      },
      {
        type: 'actionNode',
        color: 'bg-purple-500',
        label: 'Action',
      },
      {
        type: 'endNode',
        color: 'bg-red-500',
        label: 'End',
      },
    ],
    []
  );

  return (
    <Card className="w-full h-[600px]">
      <CardHeader className="p-4">
        <div className="flex justify-between items-center">
          <CardTitle>Workflow Designer</CardTitle>
          <div className="flex space-x-2">
            <Button size="sm" variant="outline" onClick={() => {}}>
              <FileUp className="h-4 w-4 mr-2" />
              Import
            </Button>
            <Button size="sm" variant="outline" onClick={() => {}}>
              <FileDown className="h-4 w-4 mr-2" />
              Export
            </Button>
            <Button
              size="sm"
              onClick={handleSaveWorkflow}
            >
              <Save className="h-4 w-4 mr-2" />
              Save
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0 h-[520px]">
        <ReactFlowProvider>
          <div className="h-full">
            <ReactFlow
              nodes={nodes}
              edges={edges}
              onNodesChange={onNodesChange}
              onEdgesChange={onEdgesChange}
              onConnect={onConnect}
              onPaneClick={handlePaneClick}
              nodeTypes={nodeTypes}
              fitView
              attributionPosition="bottom-right"
            >
              <Controls />
              <MiniMap />
              <Background gap={12} size={1} />
              <Panel position="top-left" className="bg-white p-2 rounded-md shadow-md flex-col space-y-2">
                <div className="text-sm font-medium mb-2">Add Node</div>
                <div className="flex flex-col gap-2">
                  {nodeButtons.map((btn) => (
                    <Button
                      key={btn.type}
                      size="sm"
                      variant="outline"
                      className={`flex items-center justify-start ${
                        selectedNodeType === btn.type ? 'ring-2 ring-primary' : ''
                      }`}
                      onClick={() => handleAddNode(btn.type)}
                    >
                      <div className={`w-3 h-3 rounded-full ${btn.color} mr-2`}></div>
                      {btn.label}
                    </Button>
                  ))}
                </div>
              </Panel>
              <Panel position="top-right" className="bg-white p-2 rounded-md shadow-md">
                <Button
                  size="sm"
                  variant="destructive"
                  onClick={() => setNodes([])}
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Clear
                </Button>
              </Panel>
              {selectedNodeType && (
                <Panel position="bottom-center" className="bg-white p-2 rounded-md shadow-md">
                  <div className="text-sm">
                    Click on the canvas to place a {getNodeDefaultLabel(selectedNodeType)} node
                  </div>
                </Panel>
              )}
            </ReactFlow>
          </div>
        </ReactFlowProvider>
      </CardContent>
    </Card>
  );
};

export default WorkflowDesigner;
