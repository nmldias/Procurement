import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '../ui/card';
import { Button } from '../ui/button';
import {
  CheckCircle2,
  GitBranch,
  Zap,
  Square,
  Play,
  PlusCircle,
  Trash2
} from 'lucide-react';

// A simplified workflow designer that doesn't rely on ReactFlow
const SimpleWorkflowDesigner: React.FC = () => {
  const [nodes, setNodes] = useState<{ id: string; type: string; label: string }[]>([
    { id: 'start-1', type: 'start', label: 'Start' },
  ]);

  const addNode = (type: string) => {
    const nodeTypes: Record<string, string> = {
      approval: 'Approval',
      condition: 'Condition',
      action: 'Action',
      end: 'End'
    };

    setNodes([
      ...nodes,
      {
        id: `${type}-${Date.now()}`,
        type,
        label: nodeTypes[type] || 'Node'
      }
    ]);
  };

  const removeLastNode = () => {
    if (nodes.length > 1) {
      setNodes(nodes.slice(0, -1));
    }
  };

  const getNodeIcon = (type: string) => {
    switch (type) {
      case 'start':
        return <Play className="h-5 w-5" />;
      case 'approval':
        return <CheckCircle2 className="h-5 w-5" />;
      case 'condition':
        return <GitBranch className="h-5 w-5" />;
      case 'action':
        return <Zap className="h-5 w-5" />;
      case 'end':
        return <Square className="h-5 w-5" />;
      default:
        return null;
    }
  };

  const getNodeColor = (type: string) => {
    switch (type) {
      case 'start':
        return 'bg-green-100 border-green-500 text-green-700';
      case 'approval':
        return 'bg-blue-100 border-blue-500 text-blue-700';
      case 'condition':
        return 'bg-amber-100 border-amber-500 text-amber-700';
      case 'action':
        return 'bg-purple-100 border-purple-500 text-purple-700';
      case 'end':
        return 'bg-red-100 border-red-500 text-red-700';
      default:
        return 'bg-gray-100 border-gray-500 text-gray-700';
    }
  };

  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center justify-between p-4">
        <CardTitle className="text-lg">Workflow Designer</CardTitle>
        <div className="flex space-x-2">
          <Button variant="outline" size="sm" onClick={() => removeLastNode()}>
            <Trash2 className="h-4 w-4 mr-1" />
            Remove Last
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div className="flex p-4 space-x-2 border-b">
          <Button
            variant="outline"
            size="sm"
            onClick={() => addNode('approval')}
            className="flex items-center justify-start"
          >
            <div className="w-3 h-3 rounded-full bg-blue-500 mr-2"></div>
            Approval
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => addNode('condition')}
            className="flex items-center justify-start"
          >
            <div className="w-3 h-3 rounded-full bg-amber-500 mr-2"></div>
            Condition
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => addNode('action')}
            className="flex items-center justify-start"
          >
            <div className="w-3 h-3 rounded-full bg-purple-500 mr-2"></div>
            Action
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => addNode('end')}
            className="flex items-center justify-start"
          >
            <div className="w-3 h-3 rounded-full bg-red-500 mr-2"></div>
            End
          </Button>
        </div>

        <div className="flex flex-col items-center p-8 min-h-[400px] bg-gray-50">
          {nodes.map((node, index) => (
            <React.Fragment key={node.id}>
              <div className={`flex items-center p-3 rounded-md shadow-sm border ${getNodeColor(node.type)} min-w-[200px]`}>
                <div className="mr-2">
                  {getNodeIcon(node.type)}
                </div>
                <div>
                  <div className="font-medium">{node.label}</div>
                  <div className="text-xs opacity-70">
                    {node.type === 'approval' ? 'Awaiting approval' :
                     node.type === 'condition' ? 'Check condition' :
                     node.type === 'action' ? 'Perform action' :
                     node.type === 'end' ? 'End workflow' : 'Start workflow'}
                  </div>
                </div>
              </div>

              {/* Add connecting line and plus button if not the last node */}
              {index < nodes.length - 1 && (
                <div className="flex flex-col items-center my-2">
                  <div className="h-8 w-0.5 bg-gray-300"></div>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="rounded-full h-6 w-6 p-0"
                    onClick={() => {
                      const newNodes = [...nodes];
                      newNodes.splice(index + 1, 0, {
                        id: `action-${Date.now()}`,
                        type: 'action',
                        label: 'Action'
                      });
                      setNodes(newNodes);
                    }}
                  >
                    <PlusCircle className="h-4 w-4" />
                  </Button>
                  <div className="h-8 w-0.5 bg-gray-300"></div>
                </div>
              )}
            </React.Fragment>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default SimpleWorkflowDesigner;
