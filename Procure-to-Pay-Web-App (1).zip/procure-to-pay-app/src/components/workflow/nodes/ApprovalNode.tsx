import * as React from 'react';
import { Handle, Position, NodeProps } from 'reactflow';
import { CheckCircle2, User } from 'lucide-react';

const ApprovalNode = ({ data }: NodeProps) => {
  return (
    <div className="px-4 py-2 shadow-md rounded-md bg-white border-2 border-blue-500">
      <div className="flex items-center">
        <div className="rounded-full w-8 h-8 flex justify-center items-center bg-blue-500 text-white">
          <CheckCircle2 size={16} />
        </div>
        <div className="ml-2">
          <div className="text-sm font-bold">{data.label}</div>
          <div className="text-xs flex items-center text-gray-500">
            <User size={12} className="mr-1" />
            {data.approver || 'Approver'}
          </div>
        </div>
      </div>

      {/* Input handle */}
      <Handle
        type="target"
        position={Position.Top}
        className="w-3 h-3 bg-blue-500"
      />

      {/* Approved output handle */}
      <Handle
        type="source"
        position={Position.Bottom}
        id="approved"
        className="w-3 h-3 bg-green-500"
      />

      {/* Rejected output handle */}
      <Handle
        type="source"
        position={Position.Right}
        id="rejected"
        className="w-3 h-3 bg-red-500"
      />
    </div>
  );
};

export default React.memo(ApprovalNode);
