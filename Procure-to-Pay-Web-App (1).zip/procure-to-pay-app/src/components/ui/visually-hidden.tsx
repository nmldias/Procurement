import React from 'react';

interface VisuallyHiddenProps {
  children: React.ReactNode;
}

/**
 * VisuallyHidden component
 *
 * Used to hide content visually but keep it accessible to screen readers
 * This is an accessibility best practice for providing context to screen reader users
 * without affecting the visual design.
 */
export const VisuallyHidden: React.FC<VisuallyHiddenProps> = ({ children }) => {
  return (
    <span
      className="absolute w-px h-px p-0 -m-px overflow-hidden whitespace-nowrap border-0"
      style={{
        clip: 'rect(0, 0, 0, 0)',
        clipPath: 'inset(50%)',
      }}
    >
      {children}
    </span>
  );
};
