import React from 'react'
import { LucideIcon } from 'lucide-react'
import { Button } from './button'

interface EmptyStateProps {
  /** The title of the empty state */
  title: string
  /** Description text providing more context */
  description?: string
  /** Icon component to display (Lucide icon) */
  icon?: LucideIcon
  /** Primary action button text */
  actionLabel?: string
  /** Secondary action button text */
  secondaryActionLabel?: string
  /** Handler for primary action button click */
  onAction?: () => void
  /** Handler for secondary action button click */
  onSecondaryAction?: () => void
  /** Additional CSS classes */
  className?: string
  /** The size of the empty state component */
  size?: 'sm' | 'md' | 'lg'
  /** Whether the empty state is inside a table */
  inTable?: boolean
  /** Image URL to display instead of an icon */
  imageUrl?: string
}

/**
 * EmptyState component
 *
 * A versatile component for displaying empty states throughout the application.
 * Used when no data is available or as a first-time user experience.
 */
export function EmptyState({
  title,
  description,
  icon: Icon,
  actionLabel,
  secondaryActionLabel,
  onAction,
  onSecondaryAction,
  className = '',
  size = 'md',
  inTable = false,
  imageUrl
}: EmptyStateProps) {
  const sizeClasses = {
    sm: 'py-6',
    md: 'py-10',
    lg: 'py-16'
  }

  const iconSizes = {
    sm: 'h-8 w-8',
    md: 'h-12 w-12',
    lg: 'h-16 w-16'
  }

  const baseClasses = inTable
    ? 'text-center w-full'
    : 'rounded-lg border border-dashed border-gray-300 bg-white text-center px-6'

  return (
    <div
      className={`${baseClasses} ${sizeClasses[size]} ${className}`}
      role="region"
      aria-label={title}
    >
      <div className="flex flex-col items-center justify-center space-y-3">
        {imageUrl ? (
          <img src={imageUrl} alt="" className="mx-auto h-24 w-auto" />
        ) : Icon ? (
          <Icon className={`${iconSizes[size]} text-gray-400`} aria-hidden="true" />
        ) : null}

        <h3 className="text-lg font-medium text-gray-900">{title}</h3>

        {description && (
          <p className="max-w-sm text-sm text-gray-500">{description}</p>
        )}

        {(actionLabel || secondaryActionLabel) && (
          <div className="mt-3 flex flex-col sm:flex-row gap-2">
            {actionLabel && (
              <Button
                onClick={onAction}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                {actionLabel}
              </Button>
            )}

            {secondaryActionLabel && (
              <Button
                variant="outline"
                onClick={onSecondaryAction}
              >
                {secondaryActionLabel}
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
